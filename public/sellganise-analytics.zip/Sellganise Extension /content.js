/**
 * Sellganise Analytics - content.js
 *
 * Runs on Vinted UK single-item pages. Reads the listing's Title, Brand and
 * Price directly from the page DOM, searches Vinted's own catalog for
 * comparable items (using the user's existing authenticated session,
 * entirely client-side), and injects an analytics card inline in the
 * listing's action sidebar showing the average market price and how the
 * current listing compares to it.
 *
 * No data ever leaves the browser to any third-party server - the only
 * network call made is a normal fetch() to vinted.co.uk itself, the same
 * domain the user is already browsing.
 */

(function () {
  'use strict';

  const CARD_ID = 'sellganise-analytics-card';
  const ITEM_PATH_RE = /^\/items\/(\d+)/;

  // How far a listing's price has to sit from the calculated average
  // before we flag it as a bargain or overpriced, rather than "fair".
  const BARGAIN_THRESHOLD = 0.85; // <= 85% of average
  const OVERPRICED_THRESHOLD = 1.15; // >= 115% of average

  // Candidate selectors for the sidebar block that holds the price / Buy
  // now / Favourite buttons, tried in priority order. Vinted's markup can
  // change, so this list has several fallbacks; if none match, the card
  // falls back to a fixed floating position.
  const INJECTION_TARGET_SELECTORS = [
    '[data-testid="item-page-summary-actions"]',
    '[data-testid="item-buy-button"]',
    '[data-testid="item-page-summary-price"]',
    '[data-testid="item-page-summary"]',
    '.item-page-summary-price',
  ];

  const MAX_INJECTION_RETRIES = 8;
  const RETRY_DELAY_MS = 400;

  let lastUrl = location.href;
  let currentRunToken = 0; // guards against stale async results after navigation

  /* --------------------------------------------------------------------
   * Bootstrapping / SPA navigation handling
   * ------------------------------------------------------------------ */

  function init() {
    const token = ++currentRunToken;
    removeCard();

    if (!ITEM_PATH_RE.test(location.pathname)) {
      return;
    }

    mountCard(buildLoadingCardContent(), token, 0);

    // Vinted hydrates its React tree asynchronously, so give the DOM a
    // moment to settle before we try to read it.
    setTimeout(() => runAnalysis(token), 700);
  }

  async function runAnalysis(token) {
    if (token !== currentRunToken) return;

    const info = extractProductInfo();

    if (!info.title) {
      if (token === currentRunToken) {
        mountCard(buildErrorCardContent("Couldn't read this listing's details."), token, 0);
      }
      return;
    }

    try {
      const stats = await searchSimilarItems(info);
      if (token !== currentRunToken) return; // navigated away meanwhile

      logDiagnostics(info, stats);

      if (!stats || stats.count === 0) {
        mountCard(buildEmptyCardContent(info), token, 0);
      } else {
        mountCard(buildResultsCardContent(info, stats), token, 0);
      }
    } catch (err) {
      console.warn('[Sellganise Analytics] search failed:', err);
      if (token === currentRunToken) {
        mountCard(buildErrorCardContent('Could not fetch comparable listings.'), token, 0);
      }
    }
  }

  // Prints a readable summary to the devtools console so it's easy to
  // check whether size/condition extraction and matching actually engaged
  // for a given listing, without needing to add breakpoints.
  function logDiagnostics(info, stats) {
    try {
      console.groupCollapsed('[Sellganise Analytics] diagnostics');
      console.log('Extracted from this listing:', {
        title: info.title,
        brand: info.brand,
        price: info.price,
        size: info.size,
        condition: info.condition,
        sizeSource: info._sizeSource, // 'embedded' (reliable) | 'dom' (best-effort) | null
        conditionSource: info._conditionSource,
        catalogId: info.catalogId,
        brandId: info.brandId,
        sizeId: info.sizeId,
      });
      if (stats && stats.count) {
        console.log('Comp pool:', {
          usedIdFilters: stats.usedIdFilters,
          totalFoundBeforeFiltering: stats.totalFound,
          finalCompCount: stats.count,
          matchedBySize: stats.matchedBySize,
          matchedByCondition: stats.matchedByCondition,
          confidence: stats.confidence,
        });
        if (!info.catalogId && !info.brandId && !info.sizeId) {
          console.log(
            '%cNo catalog/brand/size IDs found in embedded page data - search is falling back to plain keyword text, which is less precise.',
            'color: #b45309'
          );
        }
        if (!info.size) {
          console.log(
            '%cNo size was extracted from this page - size selectors likely need adjusting for this listing type.',
            'color: #b45309'
          );
        }
        if (!info.condition) {
          console.log(
            '%cNo condition was extracted from this page - condition selectors likely need adjusting.',
            'color: #b45309'
          );
        }
      }
      console.groupEnd();
    } catch (e) {
      // Diagnostics must never break the actual feature.
    }
  }

  // Vinted is a single-page app, so full "page load" events won't fire on
  // in-app navigation between listings. Watch the URL for changes, backed
  // by both a MutationObserver and a polling fallback for robustness.
  function handlePossibleNavigation() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      init();
    }
  }

  const navObserver = new MutationObserver(handlePossibleNavigation);
  navObserver.observe(document.documentElement, { childList: true, subtree: true });

  window.addEventListener('popstate', handlePossibleNavigation);
  setInterval(handlePossibleNavigation, 800); // safety net for SPA transitions

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* --------------------------------------------------------------------
   * DOM extraction
   * ------------------------------------------------------------------ */

  // Common noise words that pollute keyword search matching without
  // helping identify the actual product - stripped before building queries.
  const TITLE_NOISE_WORDS = [
    'bnwt', 'bnwot', 'nwt', 'brand new', 'new with tags', 'new without tags',
    'rare', 'vintage', 'authentic', 'genuine', 'sale', 'reduced', 'new',
    'excellent condition', 'like new',
  ];

  function extractProductInfo() {
    const currentId = getCurrentItemId();
    const fromEmbedded = currentId ? extractFromEmbeddedJson(currentId) : null;
    const fromLd = extractFromJsonLd();
    const fromDom = extractFromDom();

    return {
      title: (fromEmbedded && fromEmbedded.title) || fromLd.title || fromDom.title,
      brand: (fromEmbedded && fromEmbedded.brand) || fromLd.brand || fromDom.brand,
      price: (fromEmbedded && fromEmbedded.price) ?? fromLd.price ?? fromDom.price,
      size: (fromEmbedded && fromEmbedded.size) || fromDom.size,
      condition: (fromEmbedded && fromEmbedded.condition) || fromDom.condition,
      catalogId: fromEmbedded && fromEmbedded.catalogId,
      brandId: fromEmbedded && fromEmbedded.brandId,
      sizeId: fromEmbedded && fromEmbedded.sizeId,
      // Marks whether size/condition came from the reliable structured
      // source vs. a best-effort DOM text scrape, purely for diagnostics.
      _sizeSource: fromEmbedded && fromEmbedded.size ? 'embedded' : fromDom.size ? 'dom' : null,
      _conditionSource: fromEmbedded && fromEmbedded.condition ? 'embedded' : fromDom.condition ? 'dom' : null,
    };
  }

  // Most modern web apps (React/Next/Vue SSR, etc.) embed the exact data
  // structure the page was rendered from in a <script type="application/
  // json"> tag. That's far more reliable than scraping visible DOM text,
  // because it's the real source data (with stable field names) rather
  // than styled elements whose class names can change on any deploy.
  // We search every such script tag for a node whose id matches the
  // current listing's own ID (from the URL), rather than assuming a
  // specific script tag name, since we can't verify Vinted's exact bundler
  // output ahead of time.
  const MAX_JSON_SCAN_DEPTH = 14;
  const MAX_JSON_NODES_VISITED = 20000;

  function extractFromEmbeddedJson(currentId) {
    const scripts = document.querySelectorAll(
      'script[type="application/json"], script#__NEXT_DATA__'
    );

    for (const script of scripts) {
      let parsed;
      try {
        parsed = JSON.parse(script.textContent);
      } catch (e) {
        continue;
      }

      const budget = { remaining: MAX_JSON_NODES_VISITED };
      const found = findItemNodeById(parsed, currentId, new Set(), 0, budget);
      if (found) return normalizeEmbeddedItemNode(found);
    }

    return null;
  }

  function findItemNodeById(node, currentId, visited, depth, budget) {
    if (budget.remaining-- <= 0) return null;
    if (depth > MAX_JSON_SCAN_DEPTH || node === null || typeof node !== 'object') return null;
    if (visited.has(node)) return null;
    visited.add(node);

    if (looksLikeTargetItemNode(node, currentId)) return node;

    if (Array.isArray(node)) {
      for (const child of node) {
        const found = findItemNodeById(child, currentId, visited, depth + 1, budget);
        if (found) return found;
      }
    } else {
      for (const key of Object.keys(node)) {
        const found = findItemNodeById(node[key], currentId, visited, depth + 1, budget);
        if (found) return found;
      }
    }

    return null;
  }

  function looksLikeTargetItemNode(node, currentId) {
    if (!node || typeof node !== 'object' || Array.isArray(node)) return false;
    const idMatches = node.id !== undefined && String(node.id) === String(currentId);
    if (!idMatches) return false;
    // Guard against matching an unrelated node that happens to reuse the
    // same numeric id (e.g. a review count) by requiring at least one
    // product-shaped field alongside the id.
    return (
      typeof node.title === 'string' ||
      typeof node.brand_title === 'string' ||
      typeof node.size_title === 'string' ||
      (node.brand && typeof node.brand === 'object')
    );
  }

  function normalizeEmbeddedItemNode(node) {
    const brandValue =
      (node.brand && (node.brand.title || node.brand.name)) || node.brand_title || null;

    return {
      title: typeof node.title === 'string' ? node.title.trim() : null,
      brand: typeof brandValue === 'string' ? brandValue.trim() : null,
      price: parsePriceValue(node),
      size: node.size_title || node.size || null,
      condition: node.status || node.condition || null,
      catalogId: node.catalog_id ?? (node.catalog && node.catalog.id) ?? null,
      brandId: (node.brand && node.brand.id) ?? node.brand_id ?? null,
      sizeId: node.size_id ?? null,
    };
  }

  function extractFromJsonLd() {
    const scripts = document.querySelectorAll('script[type="application/ld+json"]');

    for (const script of scripts) {
      let data;
      try {
        data = JSON.parse(script.textContent);
      } catch (e) {
        continue;
      }

      const candidates = Array.isArray(data) ? data : [data];

      for (const entry of candidates) {
        if (!entry) continue;
        const type = entry['@type'];
        const isProduct = type === 'Product' || (Array.isArray(type) && type.includes('Product'));
        if (!isProduct) continue;

        const brandValue =
          (entry.brand && (entry.brand.name || entry.brand)) ||
          (entry.manufacturer && (entry.manufacturer.name || entry.manufacturer)) ||
          null;

        const offer = Array.isArray(entry.offers) ? entry.offers[0] : entry.offers;
        const priceValue = offer && (offer.price ?? offer.lowPrice);
        const parsedPrice = priceValue !== undefined ? parseFloat(priceValue) : NaN;

        return {
          title: typeof entry.name === 'string' ? entry.name.trim() : null,
          brand: typeof brandValue === 'string' ? brandValue.trim() : null,
          price: Number.isFinite(parsedPrice) ? parsedPrice : null,
        };
      }
    }

    return { title: null, brand: null, price: null };
  }

  function extractFromDom() {
    const titleSelectors = [
      'h1[data-testid="item-page-summary-title"]',
      '[data-testid="item-page-summary-title"]',
      'h1',
    ];

    const brandSelectors = [
      '[data-testid="item-page-summary-brand"] a',
      '[data-testid="item-page-summary-brand"]',
      'a[itemprop="brand"]',
      '[itemprop="brand"]',
    ];

    const priceSelectors = [
      '[data-testid="item-page-summary-price"]',
      '[itemprop="price"]',
      '.item-page-summary-price',
    ];

    const sizeSelectors = [
      '[data-testid="item-page-summary-size"]',
      '[data-testid="item-details-size"]',
      '[data-testid="item-attributes-size"]',
      '[itemprop="size"]',
      '.item-page-summary-size',
    ];

    const conditionSelectors = [
      '[data-testid="item-page-summary-condition"]',
      '[data-testid="item-details-condition"]',
      '[data-testid="item-attributes-status"]',
      '.item-page-summary-condition',
    ];

    const title = findFirstText(titleSelectors);
    const brand = findFirstText(brandSelectors);
    const priceText = findFirstText(priceSelectors);
    const price = priceText ? parseFloat(priceText.replace(/[^0-9.,]/g, '').replace(',', '.')) : null;
    const size = findFirstText(sizeSelectors);
    const condition = findFirstText(conditionSelectors);

    return {
      title,
      brand,
      price: Number.isFinite(price) ? price : null,
      size,
      condition,
    };
  }

  function findFirstText(selectors) {
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      const text = el && el.textContent && el.textContent.trim();
      if (text) return text;
    }
    return null;
  }

  function getCurrentItemId() {
    const match = location.pathname.match(ITEM_PATH_RE);
    return match ? match[1] : null;
  }

  function cleanTitleForSearch(title) {
    if (!title) return '';
    let cleaned = title.toLowerCase();
    for (const noise of TITLE_NOISE_WORDS) {
      cleaned = cleaned.replace(new RegExp(`\\b${noise}\\b`, 'gi'), ' ');
    }
    return cleaned.replace(/\s+/g, ' ').trim();
  }

  function normalizeForCompare(value) {
    return typeof value === 'string' ? value.trim().toLowerCase() : null;
  }

  /* --------------------------------------------------------------------
   * Search + price calculation
   * ------------------------------------------------------------------ */

  function buildSearchQuery(info) {
    const cleanedTitle = cleanTitleForSearch(info.title);
    return [info.brand, cleanedTitle].filter(Boolean).join(' ').trim().slice(0, 90);
  }

  function buildSearchUrl(info, query) {
    const params = new URLSearchParams();
    params.set('search_text', query);
    params.set('per_page', '48');
    params.set('order', 'relevance');

    // If we managed to pull real catalog/brand/size IDs out of the page's
    // own embedded data, use them to filter server-side - this is far more
    // precise than keyword text search, since it matches Vinted's actual
    // taxonomy rather than guessing from title wording. These param names
    // follow Vinted's common bracketed-array query convention; if they
    // turn out to be named differently, the API should simply ignore
    // unrecognized params and fall back to the text search.
    if (info.catalogId) params.append('catalog_ids[]', String(info.catalogId));
    if (info.brandId) params.append('brand_ids[]', String(info.brandId));
    if (info.sizeId) params.append('size_ids[]', String(info.sizeId));

    return `https://www.vinted.co.uk/api/v2/catalog/items?${params.toString()}`;
  }

  async function searchSimilarItems(info) {
    const query = buildSearchQuery(info);
    if (!query) return { count: 0 };

    const currentId = getCurrentItemId();
    let usedIdFilters = Boolean(info.catalogId || info.brandId || info.sizeId);
    let res = await fetch(buildSearchUrl(info, query), {
      credentials: 'include',
      headers: { Accept: 'application/json' },
    });

    // If the ID-filtered request fails for any reason (e.g. a param name
    // we guessed wrong), fall back to a plain text-only search rather than
    // surfacing an error - degrade gracefully instead of failing outright.
    if (!res.ok && usedIdFilters) {
      usedIdFilters = false;
      res = await fetch(buildSearchUrl({}, query), {
        credentials: 'include',
        headers: { Accept: 'application/json' },
      });
    }

    if (!res.ok) {
      throw new Error('Vinted search request failed with status ' + res.status);
    }

    const data = await res.json();
    const rawItems = Array.isArray(data.items) ? data.items : [];

    const items = rawItems.filter((it) => String(it.id) !== String(currentId));

    let priced = items
      .map((it) => ({ item: it, price: parsePriceValue(it) }))
      .filter((p) => typeof p.price === 'number' && Number.isFinite(p.price) && p.price > 0);

    if (!priced.length) {
      return { count: 0 };
    }

    const totalFound = priced.length;

    // Narrow down to matching size / condition where we can, but fall back
    // gracefully to the wider pool if that leaves too few comps to be
    // useful - a tight-but-empty comparison is worse than a loose one.
    const MIN_USEFUL_SAMPLE = 4;
    let matchedBySize = false;
    let matchedByCondition = false;

    if (info.size) {
      const sizeFiltered = priced.filter((p) => sizesMatch(info.size, parseSizeValue(p.item)));
      if (sizeFiltered.length >= MIN_USEFUL_SAMPLE) {
        priced = sizeFiltered;
        matchedBySize = true;
      }
    }

    if (info.condition) {
      const conditionFiltered = priced.filter((p) =>
        conditionsMatch(info.condition, parseConditionValue(p.item))
      );
      if (conditionFiltered.length >= MIN_USEFUL_SAMPLE) {
        priced = conditionFiltered;
        matchedByCondition = true;
      }
    }

    // Strip statistical outliers (e.g. mispriced or joke listings) using a
    // standard IQR fence, so one wild price doesn't skew the average.
    priced = removeOutliers(priced);

    priced.sort((a, b) => a.price - b.price);
    const prices = priced.map((p) => p.price);

    const sum = prices.reduce((acc, p) => acc + p, 0);
    const average = sum / prices.length;
    const median = prices[Math.floor(prices.length / 2)];
    const currency = detectCurrency(items);

    // "List at" / "Offer at" are percentile-based suggestions derived from
    // the spread of comparable ACTIVE listings - an ambitious asking price
    // vs. a lower quick-sale price. These are estimates, not guarantees.
    const listAt = percentile(prices, 0.75);
    const offerAt = percentile(prices, 0.25);

    const demand = estimateDemand(priced.map((p) => p.item));

    // A handful of comps produces a much shakier average than a few dozen -
    // surface that honestly rather than showing every estimate with equal
    // apparent confidence.
    const confidence = prices.length >= 10 ? 'high' : prices.length >= 5 ? 'medium' : 'low';

    return {
      count: prices.length,
      totalFound,
      average,
      median,
      min: prices[0],
      max: prices[prices.length - 1],
      currency,
      listAt,
      offerAt,
      demand, // { tier: 'low'|'medium'|'high'|null, label }
      confidence, // 'low' | 'medium' | 'high'
      matchedBySize,
      matchedByCondition,
      usedIdFilters,
    };
  }

  function percentile(sortedPrices, p) {
    if (!sortedPrices.length) return null;
    const idx = Math.min(sortedPrices.length - 1, Math.floor(p * sortedPrices.length));
    return sortedPrices[idx];
  }

  // Standard Tukey IQR fence: drop prices outside 1.5x the interquartile
  // range. Applied conservatively - if it would strip the sample down too
  // far (e.g. a tiny sample where every price looks "extreme"), skip it
  // rather than throwing away real data.
  function removeOutliers(pricedItems) {
    if (pricedItems.length < 5) return pricedItems;

    const sorted = [...pricedItems].sort((a, b) => a.price - b.price);
    const prices = sorted.map((p) => p.price);

    const q1 = percentile(prices, 0.25);
    const q3 = percentile(prices, 0.75);
    const iqr = q3 - q1;
    const lowerFence = q1 - 1.5 * iqr;
    const upperFence = q3 + 1.5 * iqr;

    const filtered = sorted.filter((p) => p.price >= lowerFence && p.price <= upperFence);

    return filtered.length >= Math.max(3, Math.floor(pricedItems.length * 0.5))
      ? filtered
      : pricedItems;
  }

  function parseSizeValue(item) {
    if (!item) return null;
    return item.size_title || item.size || item.size_title_long || null;
  }

  function parseConditionValue(item) {
    if (!item) return null;
    return item.status || item.condition || null;
  }

  function sizesMatch(currentSize, compSize) {
    const a = normalizeForCompare(currentSize);
    const b = normalizeForCompare(compSize);
    if (!a || !b) return false;
    return a === b || a.includes(b) || b.includes(a);
  }

  function conditionsMatch(currentCondition, compCondition) {
    const a = normalizeForCompare(currentCondition);
    const b = normalizeForCompare(compCondition);
    if (!a || !b) return false;
    return a === b;
  }

  // Rough demand proxy from comparable ACTIVE listings' engagement
  // (favourites-per-day-listed, if Vinted exposes that field). Vinted's
  // public search does not expose actual sold/sell-through timing, so this
  // is explicitly a heuristic "demand" signal - it is not a sell-speed
  // guarantee and should be labeled as an estimate in the UI.
  function estimateDemand(rawItems) {
    const rates = [];

    for (const it of rawItems) {
      const favourites =
        typeof it.favourite_count === 'number'
          ? it.favourite_count
          : typeof it.favourite_count_string === 'string'
          ? parseFloat(it.favourite_count_string)
          : null;

      const createdAt = it.photo && it.photo.high_resolution && it.photo.high_resolution.timestamp
        ? it.photo.high_resolution.timestamp * 1000
        : (it.created_at_ts ? it.created_at_ts * 1000 : null);

      if (favourites === null || !createdAt) continue;

      const daysListed = Math.max(1, (Date.now() - createdAt) / 86400000);
      rates.push(favourites / daysListed);
    }

    if (!rates.length) {
      return { tier: null, label: 'Not enough data' };
    }

    rates.sort((a, b) => a - b);
    const medianRate = rates[Math.floor(rates.length / 2)];

    if (medianRate >= 1) return { tier: 'high', label: 'Fast' };
    if (medianRate >= 0.2) return { tier: 'medium', label: 'Moderate' };
    return { tier: 'low', label: 'Slow' };
  }

  function parsePriceValue(item) {
    if (item && typeof item.price === 'object' && item.price !== null) {
      const amt = item.price.amount ?? item.price.value;
      const parsed = amt !== undefined ? parseFloat(amt) : NaN;
      return Number.isFinite(parsed) ? parsed : null;
    }
    if (item && item.price_numeric !== undefined) {
      const parsed = parseFloat(item.price_numeric);
      return Number.isFinite(parsed) ? parsed : null;
    }
    if (item && (typeof item.price === 'string' || typeof item.price === 'number')) {
      const parsed = parseFloat(item.price);
      return Number.isFinite(parsed) ? parsed : null;
    }
    return null;
  }

  function detectCurrency(items) {
    for (const it of items) {
      if (it.price && typeof it.price === 'object' && it.price.currency_code) {
        return it.price.currency_code;
      }
      if (it.currency) return it.currency;
    }
    return 'GBP';
  }

  function formatMoney(value, currency) {
    try {
      return new Intl.NumberFormat('en-GB', {
        style: 'currency',
        currency: currency || 'GBP',
        maximumFractionDigits: 2,
      }).format(value);
    } catch (e) {
      return `£${value.toFixed(2)}`;
    }
  }

  /* --------------------------------------------------------------------
   * Card mounting: try to inject inline into Vinted's own sidebar, right
   * below the price / Buy now / Favourite button block. If that container
   * isn't found yet (async hydration) we retry a few times before falling
   * back to a fixed floating card so the user still sees something.
   *
   * All text is inserted via textContent - never innerHTML with
   * page-derived strings, to avoid any injection risk.
   * ------------------------------------------------------------------ */

  function findInjectionTarget() {
    for (const selector of INJECTION_TARGET_SELECTORS) {
      const el = document.querySelector(selector);
      if (el) return el;
    }
    return null;
  }

  function mountCard(buildContentFn, token, attempt) {
    if (token !== currentRunToken) return;

    const target = findInjectionTarget();

    if (!target && attempt < MAX_INJECTION_RETRIES) {
      setTimeout(() => mountCard(buildContentFn, token, attempt + 1), RETRY_DELAY_MS);
      return;
    }

    injectCard(buildContentFn, target);
  }

  function injectCard(buildContentFn, target) {
    removeCard();

    const card = document.createElement('div');
    card.id = CARD_ID;
    card.className = target ? 'sga-card sga-card--inline' : 'sga-card sga-card--floating';

    const closeBtn = document.createElement('button');
    closeBtn.className = 'sga-close';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.textContent = '\u00D7';
    closeBtn.addEventListener('click', removeCard);
    card.appendChild(closeBtn);

    const header = document.createElement('div');
    header.className = 'sga-header';

    const brandName = document.createElement('span');
    brandName.className = 'sga-brand-name';
    brandName.textContent = 'Sellganise Analytics';

    const logoBadge = document.createElement('span');
    logoBadge.className = 'sga-logo-badge';
    logoBadge.textContent = '\u2B21'; // hexagon glyph, stands in for a brand mark
    logoBadge.setAttribute('title', 'Sellganise Analytics');

    header.appendChild(brandName);
    header.appendChild(logoBadge);
    card.appendChild(header);

    const body = document.createElement('div');
    body.className = 'sga-body';
    buildContentFn(body, card);
    card.appendChild(body);

    if (target && target.parentElement) {
      target.insertAdjacentElement('afterend', card);
    } else {
      document.body.appendChild(card);
    }
  }

  function removeCard() {
    const existing = document.getElementById(CARD_ID);
    if (existing) existing.remove();
  }

  function buildLoadingCardContent() {
    return (body) => {
      const spinner = document.createElement('div');
      spinner.className = 'sga-spinner';
      body.appendChild(spinner);

      const text = document.createElement('p');
      text.className = 'sga-status-text';
      text.textContent = 'Scanning similar listings...';
      body.appendChild(text);
    };
  }

  function buildErrorCardContent(message) {
    return (body) => {
      const icon = document.createElement('div');
      icon.className = 'sga-icon sga-icon-error';
      icon.textContent = '!';
      body.appendChild(icon);

      const text = document.createElement('p');
      text.className = 'sga-status-text';
      text.textContent = message;
      body.appendChild(text);
    };
  }

  function buildEmptyCardContent(info) {
    return (body) => {
      const label = document.createElement('p');
      label.className = 'sga-item-label';
      label.textContent = [info.brand, info.title].filter(Boolean).join(' \u2013 ');
      body.appendChild(label);

      const icon = document.createElement('div');
      icon.className = 'sga-icon sga-icon-empty';
      icon.textContent = '\u2014';
      body.appendChild(icon);

      const text = document.createElement('p');
      text.className = 'sga-status-text';
      text.textContent = 'No comparable listings found.';
      body.appendChild(text);
    };
  }

  function classifyPricing(currentPrice, average) {
    if (typeof currentPrice !== 'number' || !Number.isFinite(currentPrice) || !average) {
      return { tone: 'neutral', badgeText: null, positionLabel: 'At market' };
    }

    const ratio = currentPrice / average;

    if (ratio <= BARGAIN_THRESHOLD) {
      return { tone: 'good', badgeText: 'Great Deal', positionLabel: 'Under market' };
    }
    if (ratio >= OVERPRICED_THRESHOLD) {
      return { tone: 'bad', badgeText: 'Above Market', positionLabel: 'Above market' };
    }
    return { tone: 'neutral', badgeText: 'Fair Price', positionLabel: 'At market' };
  }

  function buildResultsCardContent(info, stats) {
    return (body, card) => {
      const classification = classifyPricing(info.price, stats.average);

      if (card) {
        card.classList.remove('sga-tone-good', 'sga-tone-bad', 'sga-tone-neutral');
        card.classList.add(`sga-tone-${classification.tone}`);
      }

      // Uplift badge (top-right corner pill): difference between the
      // estimated resale value and this listing's own asking price.
      if (card && typeof info.price === 'number' && Number.isFinite(info.price)) {
        const uplift = stats.average - info.price;
        if (Math.abs(uplift) >= 1) {
          const upliftBadge = document.createElement('span');
          const isPositive = uplift > 0;
          upliftBadge.className = `sga-uplift-badge ${isPositive ? 'sga-uplift-badge--up' : 'sga-uplift-badge--down'}`;
          upliftBadge.textContent = `${isPositive ? '+' : '-'}${formatMoney(Math.abs(uplift), stats.currency)}`;
          card.appendChild(upliftBadge);
        }
      }

      const label = document.createElement('p');
      label.className = 'sga-item-label';
      label.textContent = [info.brand, info.title].filter(Boolean).join(' \u2013 ');
      body.appendChild(label);

      if (classification.badgeText) {
        const badge = document.createElement('span');
        badge.className = `sga-badge sga-badge--${classification.tone}`;
        badge.textContent = classification.badgeText;
        body.appendChild(badge);
      }

      const avgLabel = document.createElement('div');
      avgLabel.className = 'sga-avg-label';
      avgLabel.textContent = 'Est. Resale Value';
      body.appendChild(avgLabel);

      const avgValue = document.createElement('div');
      avgValue.className = 'sga-avg-value';
      avgValue.textContent = formatMoney(stats.average, stats.currency);
      body.appendChild(avgValue);

      if (typeof info.price === 'number' && Number.isFinite(info.price)) {
        const currentPriceLine = document.createElement('p');
        currentPriceLine.className = 'sga-current-price';
        currentPriceLine.textContent = `This listing: ${formatMoney(info.price, stats.currency)}`;
        body.appendChild(currentPriceLine);
      }

      // --- Stat grid, mirroring a V-Hive-style breakdown -----------------
      const grid = document.createElement('div');
      grid.className = 'sga-grid';

      grid.appendChild(
        buildGridTile('\uD83D\uDCB0', 'List at', formatMoney(stats.listAt, stats.currency))
      );
      grid.appendChild(
        buildGridTile('\uD83C\uDFF7\uFE0F', 'Offer at', formatMoney(stats.offerAt, stats.currency))
      );
      grid.appendChild(
        buildGridTile('\u26A1', 'Sell speed (est.)', stats.demand.label)
      );
      grid.appendChild(
        buildGridTile('\uD83C\uDFAF', 'Position', classification.positionLabel)
      );
      grid.appendChild(
        buildGridTile(
          '\uD83D\uDCCA',
          'Market activity',
          `${stats.count} comp${stats.count === 1 ? '' : 's'}`
        )
      );
      grid.appendChild(
        buildGridTile(
          '\uD83D\uDCC4',
          'Market range',
          `${formatMoney(stats.min, stats.currency)}\u2013${formatMoney(stats.max, stats.currency)}`
        )
      );

      body.appendChild(grid);

      const matchNotes = [];
      if (stats.matchedBySize) matchNotes.push('size');
      if (stats.matchedByCondition) matchNotes.push('condition');
      if (matchNotes.length) {
        const matchLine = document.createElement('p');
        matchLine.className = 'sga-match-note';
        matchLine.textContent = `Matched by ${matchNotes.join(' & ')} \u2022 ${stats.count} of ${stats.totalFound} listings found`;
        body.appendChild(matchLine);
      }

      if (stats.confidence === 'low') {
        const confidenceNote = document.createElement('p');
        confidenceNote.className = 'sga-confidence-note';
        confidenceNote.textContent = `Low sample size (${stats.count} comps) \u2014 treat this as a rough estimate.`;
        body.appendChild(confidenceNote);
      }

      // Honest source chip - we only ever query Vinted's own search, so we
      // never imply data was pulled from other marketplaces. Tappable to
      // reveal which source(s) were actually searched.
      const sourceWrapper = document.createElement('div');
      sourceWrapper.className = 'sga-source-wrapper';

      const sourceChip = document.createElement('button');
      sourceChip.type = 'button';
      sourceChip.className = 'sga-source-chip';
      sourceChip.textContent = 'Marketplaces searched';

      const sourcePanel = document.createElement('div');
      sourcePanel.className = 'sga-source-panel';
      sourcePanel.hidden = true;

      const sourceItem = document.createElement('span');
      sourceItem.className = 'sga-source-item';
      sourceItem.textContent = '\u2022 Vinted UK';
      sourcePanel.appendChild(sourceItem);

      sourceChip.addEventListener('click', () => {
        const isOpen = !sourcePanel.hidden;
        sourcePanel.hidden = isOpen;
        sourceChip.classList.toggle('sga-source-chip--open', !isOpen);
      });

      sourceWrapper.appendChild(sourceChip);
      sourceWrapper.appendChild(sourcePanel);
      body.appendChild(sourceWrapper);

      const footer = document.createElement('p');
      footer.className = 'sga-footer-note';
      footer.textContent =
        'Estimates from live Vinted listings, calculated locally. "Demand" is a rough engagement signal, not a guaranteed sell time.';
      body.appendChild(footer);
    };
  }

  function buildGridTile(iconChar, labelText, valueText) {
    const tile = document.createElement('div');
    tile.className = 'sga-grid-tile';

    const iconRow = document.createElement('div');
    iconRow.className = 'sga-grid-icon-row';

    const icon = document.createElement('span');
    icon.className = 'sga-grid-icon';
    icon.textContent = iconChar;

    const label = document.createElement('span');
    label.className = 'sga-grid-label';
    label.textContent = labelText;

    iconRow.appendChild(icon);
    iconRow.appendChild(label);

    const value = document.createElement('div');
    value.className = 'sga-grid-value';
    value.textContent = valueText;

    tile.appendChild(iconRow);
    tile.appendChild(value);
    return tile;
  }

})();
