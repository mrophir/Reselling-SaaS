# Vinted Reseller Toolkit

A Chrome extension for Vinted reselling. Auto-refreshes catalog/search pages so you don't click refresh yourself, and stops the instant you move your cursor to look at something.

## Features

**Auto-refresh** — reload catalog/search pages on a timer. Choose 10/15/30/60s or type any custom value (min 5s).

**Stop when I move the cursor** — the moment you move the mouse (or scroll), auto-refresh switches off completely and stays off until you turn it back on in the popup. A small toast confirms it stopped. This keeps behaviour close to human and lets you inspect an item without the page reloading under you.

**New-item alerts** — when a refresh brings in unseen listings, you get a desktop notification, a toolbar badge, and the new cards are highlighted.

**Basket** — every item card gets a `+ Basket` button on hover; saved items live in the popup's Basket tab (open one, open all, remove, clear).

## Install (developer mode)

1. Go to `chrome://extensions`
2. Turn on **Developer mode** (top right)
3. Click **Load unpacked** and select this `vinted-reseller` folder
4. Open Vinted, click the toolbar icon, turn on auto-refresh

## A note on Vinted's terms

Vinted's user terms prohibit external bots/scrapers unless authorised, so an auto-refresher sits in a grey area. In practice it's a widely-used, permissive grey area and the worst-case consequence is an account suspension, not legal action. What actually triggers Vinted's bot detection is aggressive, machine-like behaviour — fast fixed intervals running 24/7. To stay low-risk: keep intervals reasonable, don't leave it running unattended for hours, and let the stop-on-move feature do its job. Use at your own discretion.

## Notes & limits

- Vinted changes its markup often. If basket buttons stop appearing, the selectors in `content.js` (`getItemCards`) may need a tweak.
- The extension can't complete a Vinted checkout — the basket is a shortlist that opens listings in Vinted's own logged-in flow.
