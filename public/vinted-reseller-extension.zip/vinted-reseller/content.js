// Vinted Reseller Toolkit — content script
// Runs on Vinted pages. Handles auto-refresh of catalog results,
// detection of newly appeared listings, and "basket" buttons on item cards.

(() => {
  "use strict";

  const DEFAULTS = {
    autoRefresh: false,
    intervalSec: 15,
    pauseOnBlur: true,
    stopOnMove: true,
    alertOnNew: true,
  };

  let settings = { ...DEFAULTS };
  let refreshTimer = null;
  let seenIds = new Set();
  let firstScanDone = false;
  let moveArmed = false; // becomes true a moment after a refresh, so the reload's own cursor jump doesn't trip it

  // ---- helpers ---------------------------------------------------------

  const isCatalogPage = () =>
    /\/catalog|\/member\/items|\/vetements|^\/$/.test(location.pathname) ||
    location.pathname === "/";

  // Vinted item cards. Selectors are kept broad because Vinted's markup
  // changes; we look for anchors pointing at /items/<id>.
  function getItemCards() {
    const anchors = document.querySelectorAll('a[href*="/items/"]');
    const cards = new Map();
    anchors.forEach((a) => {
      const m = a.href.match(/\/items\/(\d+)/);
      if (!m) return;
      const id = m[1];
      // climb to the visual card container
      const card =
        a.closest('[data-testid*="grid-item"]') ||
        a.closest("li") ||
        a.closest("div");
      if (card && !cards.has(id)) cards.set(id, { id, card, anchor: a });
    });
    return cards;
  }

  function extractItem(id, card, anchor) {
    const img = card.querySelector("img");
    const priceEl = card.querySelector(
      '[data-testid*="price"], [class*="price"], .web_ui__Text__text'
    );
    const title =
      img?.getAttribute("alt") ||
      anchor.getAttribute("title") ||
      card.querySelector('[data-testid*="title"]')?.textContent?.trim() ||
      "Vinted item";
    return {
      id,
      title: title.slice(0, 120),
      price: priceEl?.textContent?.trim() || "",
      image: img?.src || "",
      url: anchor.href.split("?")[0],
      savedAt: Date.now(),
    };
  }

  // ---- basket ----------------------------------------------------------

  function addBasketButtons() {
    const cards = getItemCards();
    cards.forEach(({ id, card, anchor }) => {
      if (card.querySelector(".vrt-basket-btn")) return;
      const btn = document.createElement("button");
      btn.className = "vrt-basket-btn";
      btn.type = "button";
      btn.title = "Add to basket";
      btn.textContent = "+ Basket";
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const item = extractItem(id, card, anchor);
        chrome.storage.local.get({ basket: [] }, ({ basket }) => {
          if (basket.some((b) => b.id === id)) {
            flash(btn, "In basket");
            return;
          }
          basket.push(item);
          chrome.storage.local.set({ basket }, () => flash(btn, "✓ Added"));
        });
      });
      // ensure the card is a positioning context
      const cs = getComputedStyle(card);
      if (cs.position === "static") card.style.position = "relative";
      card.appendChild(btn);
    });
  }

  function flash(btn, text) {
    const prev = btn.textContent;
    btn.textContent = text;
    btn.classList.add("vrt-basket-btn--done");
    setTimeout(() => {
      btn.textContent = "+ Basket";
      btn.classList.remove("vrt-basket-btn--done");
    }, 1200);
  }

  // ---- new item detection ---------------------------------------------

  function scanForNew() {
    const cards = getItemCards();
    let newCount = 0;
    const newItems = [];
    cards.forEach(({ id, card, anchor }) => {
      if (!seenIds.has(id)) {
        seenIds.add(id);
        if (firstScanDone) {
          newCount++;
          newItems.push(extractItem(id, card, anchor));
          card.classList.add("vrt-new-item");
          setTimeout(() => card.classList.remove("vrt-new-item"), 6000);
        }
      }
    });
    firstScanDone = true;
    if (newCount > 0 && settings.alertOnNew) {
      chrome.runtime.sendMessage({
        type: "NEW_ITEMS",
        count: newCount,
        sample: newItems[0],
      });
    }
  }

  // ---- auto refresh ----------------------------------------------------

  function tick() {
    if (settings.pauseOnBlur && document.hidden) return;
    location.reload();
  }

  function startRefresh() {
    stopRefresh();
    if (!settings.autoRefresh || !isCatalogPage()) return;
    const ms = Math.max(5, settings.intervalSec) * 1000;
    refreshTimer = setInterval(tick, ms);
    // arm move-detection shortly after (re)starting, so the automatic
    // cursor position on page load doesn't instantly count as "moved"
    if (settings.stopOnMove) {
      moveArmed = false;
      setTimeout(() => {
        moveArmed = true;
      }, 800);
    }
  }

  function stopRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = null;
  }

  // ---- cursor tracking (pause-on-hover) -------------------------------

  // ---- stop-on-move ---------------------------------------------------

  // Any real cursor movement switches auto-refresh OFF (persisted to
  // storage, so the popup toggle flips too) and it stays off until the
  // user turns it back on.
  function onCursorMove() {
    if (!settings.autoRefresh || !settings.stopOnMove || !moveArmed) return;
    moveArmed = false;
    stopRefresh();
    chrome.storage.local.get({ settings: DEFAULTS }, ({ settings: s }) => {
      chrome.storage.local.set({
        settings: { ...DEFAULTS, ...s, autoRefresh: false },
      });
    });
    showStoppedToast();
  }

  function attachMoveTracking() {
    document.addEventListener("mousemove", onCursorMove, { passive: true });
    document.addEventListener("wheel", onCursorMove, { passive: true });
  }

  function showStoppedToast() {
    let t = document.getElementById("vrt-toast");
    if (!t) {
      t = document.createElement("div");
      t.id = "vrt-toast";
      t.className = "vrt-toast";
      document.body.appendChild(t);
    }
    t.textContent = "Auto-refresh stopped — you moved the cursor";
    t.classList.add("vrt-toast--show");
    setTimeout(() => t.classList.remove("vrt-toast--show"), 2600);
  }

  // ---- observe DOM for infinite-scroll / new cards --------------------

  const observer = new MutationObserver(() => {
    addBasketButtons();
    scanForNew();
  });

  // ---- boot ------------------------------------------------------------

  function init() {
    chrome.storage.local.get({ settings: DEFAULTS }, (data) => {
      settings = { ...DEFAULTS, ...data.settings };
      addBasketButtons();
      scanForNew();
      attachMoveTracking();
      startRefresh();
      observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.settings) {
      settings = { ...DEFAULTS, ...changes.settings.newValue };
      startRefresh();
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
