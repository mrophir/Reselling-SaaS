// Vinted Reseller Toolkit — popup logic

const DEFAULTS = {
  autoRefresh: false,
  intervalSec: 15,
  pauseOnBlur: true,
  stopOnMove: true,
  alertOnNew: true,
};

const $ = (id) => document.getElementById(id);

// ---- load settings ----------------------------------------------------
chrome.storage.local.get({ settings: DEFAULTS }, ({ settings }) => {
  const s = { ...DEFAULTS, ...settings };
  $("autoRefresh").checked = s.autoRefresh;
  $("alertOnNew").checked = s.alertOnNew;
  $("stopOnMove").checked = s.stopOnMove;
  $("pauseOnBlur").checked = s.pauseOnBlur;
  const presets = [10, 15, 30, 60];
  document.querySelectorAll("#intervalSeg button").forEach((b) => {
    b.classList.toggle("seg--on", Number(b.dataset.sec) === s.intervalSec);
  });
  // if the saved interval isn't one of the presets, show it as custom
  $("customSec").value = presets.includes(s.intervalSec) ? "" : s.intervalSec;
  updateNote(s);
});

function save(patch) {
  chrome.storage.local.get({ settings: DEFAULTS }, ({ settings }) => {
    const next = { ...DEFAULTS, ...settings, ...patch };
    chrome.storage.local.set({ settings: next }, () => updateNote(next));
  });
}

function updateNote(s) {
  const note = $("refreshNote");
  if (!s.autoRefresh) {
    note.textContent =
      "Turn on auto-refresh, open a Vinted search or catalog page, and it will reload on your chosen interval until you move the cursor.";
  } else {
    const moveMsg = s.stopOnMove
      ? " It stops the moment you move your cursor — flip it back on here to resume."
      : "";
    note.textContent = `Refreshing every ${s.intervalSec}s on catalog pages.${moveMsg} Keep intervals reasonable — fast, machine-like refreshing is what risks a block from Vinted.`;
  }
}

// ---- switches ---------------------------------------------------------
$("autoRefresh").addEventListener("change", (e) =>
  save({ autoRefresh: e.target.checked })
);
$("alertOnNew").addEventListener("change", (e) =>
  save({ alertOnNew: e.target.checked })
);
$("stopOnMove").addEventListener("change", (e) =>
  save({ stopOnMove: e.target.checked })
);
$("pauseOnBlur").addEventListener("change", (e) =>
  save({ pauseOnBlur: e.target.checked })
);

// ---- interval segmented control --------------------------------------
$("intervalSeg").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-sec]");
  if (!btn) return;
  document
    .querySelectorAll("#intervalSeg button")
    .forEach((b) => b.classList.remove("seg--on"));
  btn.classList.add("seg--on");
  $("customSec").value = "";
  save({ intervalSec: Number(btn.dataset.sec) });
});

$("customSec").addEventListener("input", (e) => {
  const val = Number(e.target.value);
  if (!val || val < 5) return;
  document
    .querySelectorAll("#intervalSeg button")
    .forEach((b) => b.classList.remove("seg--on"));
  save({ intervalSec: val });
});

// ---- page state -------------------------------------------------------
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = tabs[0]?.url || "";
  const state = $("pageState");
  if (/vinted\./.test(url)) {
    const onCatalog = /\/catalog|\/$/.test(new URL(url).pathname);
    state.textContent = onCatalog
      ? "On a Vinted catalog page ✓"
      : "On Vinted — open a search to auto-refresh";
  } else {
    state.textContent = "Open Vinted to use auto-refresh";
  }
});

// ---- tabs -------------------------------------------------------------
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document
      .querySelectorAll(".tab")
      .forEach((t) => t.classList.remove("tab--active"));
    document
      .querySelectorAll(".panel")
      .forEach((p) => p.classList.remove("panel--active"));
    tab.classList.add("tab--active");
    $("panel-" + tab.dataset.tab).classList.add("panel--active");
  });
});

// ---- basket -----------------------------------------------------------
function renderBasket() {
  chrome.storage.local.get({ basket: [] }, ({ basket }) => {
    $("basketCount").textContent = basket.length;
    const list = $("basketList");
    const empty = $("basketEmpty");
    list.innerHTML = "";
    empty.style.display = basket.length ? "none" : "block";

    basket
      .slice()
      .reverse()
      .forEach((item) => {
        const li = document.createElement("li");
        li.className = "b-item";
        li.innerHTML = `
          <img class="b-item__img" src="${item.image}" alt="" />
          <div class="b-item__body">
            <div class="b-item__title">${escapeHtml(item.title)}</div>
            <div class="b-item__price">${escapeHtml(item.price || "—")}</div>
          </div>
          <button class="b-item__x" title="Remove">&times;</button>`;
        li.querySelector(".b-item__img").style.cursor = "pointer";
        li
          .querySelector(".b-item__img")
          .addEventListener("click", () =>
            chrome.tabs.create({ url: item.url })
          );
        li.querySelector(".b-item__title").style.cursor = "pointer";
        li
          .querySelector(".b-item__title")
          .addEventListener("click", () =>
            chrome.tabs.create({ url: item.url })
          );
        li.querySelector(".b-item__x").addEventListener("click", () =>
          removeItem(item.id)
        );
        list.appendChild(li);
      });
  });
}

function removeItem(id) {
  chrome.storage.local.get({ basket: [] }, ({ basket }) => {
    chrome.storage.local.set(
      { basket: basket.filter((b) => b.id !== id) },
      renderBasket
    );
  });
}

$("clearBasket").addEventListener("click", () => {
  chrome.storage.local.set({ basket: [] }, renderBasket);
});

$("openAll").addEventListener("click", () => {
  chrome.storage.local.get({ basket: [] }, ({ basket }) => {
    basket.forEach((item) => chrome.tabs.create({ url: item.url, active: false }));
  });
});

function escapeHtml(str) {
  return String(str).replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
}

chrome.storage.onChanged.addListener((changes) => {
  if (changes.basket) renderBasket();
  if (changes.settings) {
    const s = { ...DEFAULTS, ...changes.settings.newValue };
    $("autoRefresh").checked = s.autoRefresh;
    updateNote(s);
  }
});

renderBasket();
