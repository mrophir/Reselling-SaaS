// Vinted Reseller Toolkit — background service worker
// Receives NEW_ITEMS messages from content scripts and shows a notification.

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg?.type !== "NEW_ITEMS") return;

  const title =
    msg.count === 1
      ? "New Vinted listing"
      : `${msg.count} new Vinted listings`;
  const body = msg.sample
    ? `${msg.sample.title} — ${msg.sample.price}`
    : "Fresh items just appeared in your search.";

  chrome.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message: body,
    priority: 2,
  });

  // badge the toolbar icon briefly
  chrome.action.setBadgeBackgroundColor({ color: "#0bb07b" });
  chrome.action.setBadgeText({ text: String(msg.count), tabId: sender.tab?.id });
  setTimeout(() => {
    chrome.action.setBadgeText({ text: "", tabId: sender.tab?.id });
  }, 8000);
});

// Clicking a notification focuses the Vinted tab that raised it.
chrome.notifications.onClicked.addListener(() => {
  chrome.tabs.query({ url: "*://*.vinted.*/*" }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.update(tabs[0].id, { active: true });
      chrome.windows.update(tabs[0].windowId, { focused: true });
    }
  });
});
